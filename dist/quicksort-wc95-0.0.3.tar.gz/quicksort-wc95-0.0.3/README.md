# Quicksort Package (a sample package for CRI technical interview)
This python package contains only one function, the partition().

## Quick overview of Quicksort
The quicksort is a divide-and-conquer sorting algorithm. <br/>
The main routine of quicksort is the partition routine. <br/>
The partition routine sorts the pivot element and returns the index of the sorted pivot element.

## Installation steps


